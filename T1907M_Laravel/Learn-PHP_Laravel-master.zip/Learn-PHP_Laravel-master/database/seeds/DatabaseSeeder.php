<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
//        factory(\App\Category::class,1000)->create();
//        factory(\App\Brand::class,1000)->create();
        factory(\App\Product::class,1000)->create();
    }
}
