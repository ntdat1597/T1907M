@extends("layout")
@section("content")
    day la noi dung trang chu
@endsection
