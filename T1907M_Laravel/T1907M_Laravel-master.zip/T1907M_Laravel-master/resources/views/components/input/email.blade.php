<div class="form-group">
    <input type="email" name="{{$name}}" class="form-control" placeholder="{{$holder}}"/>
</div>
