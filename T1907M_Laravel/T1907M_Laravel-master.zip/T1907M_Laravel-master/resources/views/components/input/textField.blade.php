<div class="form-group">
    <input type="text" name="{{$name}}" class="form-control" placeholder="{{$holder}}"/>
</div>
